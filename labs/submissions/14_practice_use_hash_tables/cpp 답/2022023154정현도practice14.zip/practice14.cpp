// Practice 12. Use hash tables
#include <fstream>
#include <iostream>
#include <sstream>
#include <unordered_map>
#include <vector>
using namespace std;
const char TWO_SUM = 'T';
const char SYMMETRIC_PAIRS = 'S';
unordered_map<int,int> umap;

 //unordered map은 vector처럼 자료형 정의해줘야함

void makeHash(vector<int> nums, int n){

  umap.clear();
  int key;
   
    for (int i = 0; i < n; i++) {
        key = nums[i] % n;
        
        // 해시 충돌 처리: 이미 존재하는 키인 경우 다음 키로 이동
        while (umap.find(key) != umap.end()) {
            key = (key + 1) % n; 
        }
        
        // 키가 없으면 삽입
        umap[key] = nums[i];
       
    }

}

bool twoSome(int k, int n){
    
     for(int i = 0; i < umap.size(); i++){
     
      int complement = k - umap[i];
      
      for(int j = 0; j < n; j++){

        if(j != i && umap[j] == complement)
          return true;
      }

     }

      return false;
}

vector<pair<int,int>> symmetricPairs(vector<pair<int,int>> &pairs){
  unordered_map<int,int> umap2;
  vector<pair<int,int>> result;

  for(int i = 0; i < pairs.size(); i++){
    int a = pairs[i].first;
    int b = pairs[i].second;

    if(umap2.find(b) != umap2.end() && umap2[b] == a){
      result.push_back(make_pair(b,a));
    }
    umap2[a] = b;
  }
  return result;
}

vector<int> readIntegers(int k, string& line) {
  vector<int> arr;
  istringstream liss(line);
  int val;
  for (int i = 0; i < k; ++i) {
    if (!(liss >> val)) {
      cerr<<"Error: invalid input value"<<endl;
      exit(1);
    }
    else {
      arr.push_back(val);
    }
  }
  return arr;
}

int main(int argc, char* argv[]) {
  if (argc != 3) {
    cerr<<"Correct usage: [program] [input] [output]"<<endl;
    exit(1);
  }
  ifstream inFile(argv[1]);
  ofstream outFile(argv[2]);
  string line;
  while (getline(inFile, line))
  {
    char op = line[0];
    istringstream iss(line.substr(2));
    vector<int> nums;
    vector<pair<int, int>> pairs;
    vector<pair<int, int>> ans;
    vector<pair<int, int>>::iterator it;
    int k, n, a, b;
    bool exist;
    
   
    switch(op)
    {
      case TWO_SUM:
        if (!(iss >> k >> n)) {
          cerr<<"TWO_SUM: invalid input"<<endl;
          exit(1);
        }
        if (!getline(inFile, line)) {
          cerr<<"TWO_SUM: unable to read a line"<<endl;
          exit(1);
        }
        nums = readIntegers(n, line);

        makeHash(nums,n);

        if(twoSome(k,n)){
          outFile << "T" <<endl;
        }
        else
        outFile<<"F"<<endl;
        
        // TODO 
        // Take k and nums as input, and run twoSum(k, nums)
        // Write whether two sum exists into output file
        break;
      case SYMMETRIC_PAIRS:
        if (!(iss >> n)) {
          cerr<<"SYMMETRIC_PAIRS: invalid input"<<endl;
          exit(1);
        }
        for (int i = 0; i < n; ++i) {
          if (!getline(inFile, line)) {
            cerr<<"SYMMERIC_PAIRS: invalid input"<<endl;
            exit(1);
          }
          istringstream tiss(line);
          if (!(tiss >> a >> b)) {
            cerr<<"SYMMETRIC_PAIRS: invalid input"<<endl;
            exit(1);
          }
          pairs.push_back(make_pair(a, b));
        }
       
        ans = symmetricPairs(pairs);
       
        for (it = ans.begin(); it != ans.end(); ++it) {
          //반복자 공부 반복자는 포인터랑 같음 ans.begin은 시작점의 주소고 ++it하니까 자료형의 크기만큼 주소가 늘어날것

           outFile << it->first <<" "<< it->second << endl;
        }

        
        // TODO
        // Take pairs as input, and run symmetricPairs(pairs)
        // Write every symmetric pair into output file
        break;
      default:
        cerr<<"Undefined operator"<<endl;
        exit(1);
    }
  }
  outFile.close();
  inFile.close();
}
