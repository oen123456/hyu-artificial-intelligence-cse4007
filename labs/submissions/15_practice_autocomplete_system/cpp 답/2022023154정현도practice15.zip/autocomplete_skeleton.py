# Practice 15. Autocomplete system
import sys
BUILD_TRIE = 'T'
AUTOCOMPLETE = 'A'
ENDS_HERE = '#'


class Trie:
    def __init__(self):
        self.dict = {}                    

    def insert(self, word):
        node = self.dict
        for char in word:
            if char not in node:
                node[char] = {}
            node = node[char]
        node[ENDS_HERE] = True

    def search(self, word):
        node = self.dict
        for char in word:
            if char not in node:
                return False
            node = node[char]
        return node[ENDS_HERE]

    def starts_with(self, prefix):
        node = self.dict
        for char in prefix:
            if char not in node:
                return None
            node = node[char]
        return node

    def find_words_with_prefix(self, node, prefix):
        words = []
        stack = [(node, prefix)]

        while stack:
            current_node, current_prefix = stack.pop()
            if current_node.get(ENDS_HERE, False):
                words.append(current_prefix)
            for char, child_node in current_node.items():             #딕셔너리에서 (키,값) 쌍으로 반환하여 반복문에서 사용할 수 있도록 .items() 쓴 것
                if char != ENDS_HERE:                      
                  stack.append((child_node, current_prefix + char))
        
        return words

trie=Trie()
if __name__ == '__main__':
  if len(sys.argv) != 3:
    raise Exception("Correct usage: [program] [input] [output]")
  with open(sys.argv[1], 'r') as inFile:
    lines = inFile.readlines()
  with open(sys.argv[2], 'w') as outFile:
    i = 0
    while i < len(lines):
      words = lines[i].split()
      op = words[0]
      if op == BUILD_TRIE:
        if len(words) != 2:
          raise Exception("BUILD_TRIE: invalid input")
        n = int(words[1])
        strings = []
        while n:
          i += 1
          strings.append(lines[i].strip())
          n -= 1
        for word in strings:
           trie.insert(word)
      elif op == AUTOCOMPLETE:
        if len(words) != 2:
          raise Exception("AUTOCOMPLETE: invalid input")
        prefix = words[1]
        node = trie.starts_with(prefix)
        if node:
           results = trie.find_words_with_prefix(node,prefix)
           for word in results:
              outFile.write(word + " ")
           outFile.write("\n")
      else:
        raise Exception("Undefined operator")
      i += 1
