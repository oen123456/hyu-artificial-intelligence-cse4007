// Practice 13. Sorting 
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <iostream>
#include <sstream>
#include <vector>
using namespace std;
const char MERGE_SORT = 'M';
const char QUICK_SORT = 'Q';

vector <int> result;


int Partition(vector<int> &input, int low, int high){

  int pivot = input[high];
  int left = low;
  int right = high;

  while(left <= right){
    
    while(input[left] > pivot){
      ++left;
    }

    while(input[right] <= pivot){
      --right;
    }


    if(left < right){

      int temp;

      temp = input[left];
      input[left]=input[right];
      input[right]=temp;

    }
  }

    input[high] = input[left];
    input[left] = pivot;
    
  
  return left;
}





void Quicksort(vector<int> &input,int low,int high){
 
  if(low < high){
    int q = Partition(input,low,high);
    Quicksort(input,low,q-1);
    Quicksort(input,q+1,high);
  }
}



void Merge(vector<int> &input, vector<int> &result, int lPos, int rPos, int rEnd) {

int lEnd = rPos - 1;
int tPos = lPos;
int size = rEnd - lPos + 1;

while (lPos <= lEnd && rPos <= rEnd) {

if (input[lPos] >= input[rPos])
result[tPos++] = input[lPos++];

else
result[tPos++] = input[rPos++];
}

while (lPos <= lEnd)
result[tPos++] = input[lPos++];
while (rPos <= rEnd)
result[tPos++] = input[rPos++];

for (int i = 0; i < size; i++, --rEnd)
input[rEnd] = result[rEnd];

}

void MergeSort(vector<int> &arr, vector<int> &result,int left, int right){

  
    if(left < right){
    int mid = (left + right) / 2;

    MergeSort(arr, result, left, mid);
    MergeSort(arr, result, mid+1, right);
    Merge(arr, result, left, mid+1, right);
  }
}

int readInput(ifstream& inFile, istringstream& iss, vector<int>& input) {
  string line;
  int numInput, val;
  input.clear();
  if (!(iss >> numInput)) {
    cerr<<"Error: invalid number of input"<<endl;
    exit(1);
  }
  if (!getline(inFile, line)) {
    cerr<<"Error: unable to read a line"<<endl;
    exit(1);
  }
  istringstream viss(line);
  for (int i = 0; i < numInput; ++i) {
    if (!(viss >> val)) {
      cerr<<"Error: invalid input value"<<endl;
      exit(1);
    }
    else {
      input.push_back(val);
    }
  }
  return numInput;
}
//파싱한 숫자가 input 이라는 벡터에 들어가있음


int main(int argc, char* argv[]) {
  if (argc != 3) {
    cerr<<"Correct usage: [program] [input] [output]"<<endl;
    exit(1);
  }
  ifstream inFile(argv[1]);
  ofstream outFile(argv[2]);
  string line;
  while (getline(inFile, line))
  {
    char op = line[0];
    istringstream iss(line.substr(2));
    vector<int> arr;
    int size;
    size = readInput(inFile, iss, arr);
     result.resize(size); //vector은 resize로 초기화 해서 segment 오류가 안뜸
    switch(op)
    {
    case MERGE_SORT:

    MergeSort(arr, result,0,size-1);
    for(int i= 0; i < size; i++){
      outFile <<result[i]<<" ";
    }
    outFile << endl;
    break;

    
    
    
    case QUICK_SORT:
    Quicksort(arr,0,size-1);
    
    for(int i=0; i < size; i++){
      outFile << arr[i]<<" ";
    }
    outFile << endl;

     break;

    default:
        cerr<<"Undefined operator"<<endl;
        exit(1);
    }
  }
  outFile.close();
  inFile.close();
}
